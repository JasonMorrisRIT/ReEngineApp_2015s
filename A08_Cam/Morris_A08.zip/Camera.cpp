#include "Camera.h"
Camera* Camera::instance = nullptr;