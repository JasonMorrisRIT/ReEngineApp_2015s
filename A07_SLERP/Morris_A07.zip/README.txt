Didn't do any bonus credit. All work done in Quats.
Time based actions are a little off due to rounding errors
but besides that should be all good.
-Jason Morris